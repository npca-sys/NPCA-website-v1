#include <stdio.h>
#include <stdlib.h>

unsigned int MaxSupeCon=21561984;
unsigned int MaxPrime=21561984/2048;
unsigned int PrimeTable[24270];
unsigned int n;
unsigned int SupeTable[25600];
int CountSupe=0; 
int CountPrime = 0;

int comp(const void *x,const void *y);
int SupeCon(int Depth,int Border,int Num);
void CreateFactor();

int main(void)
{
	char In[30];
	printf("n���ĉ��������Ă��ꂽ��������Ȃ�\n");
	gets(In);
	n=atoi(In);

	CreateFactor();

	SupeCon(1,0,1);

	qsort(SupeTable,CountSupe,sizeof(int),comp);

	printf("%d\n",SupeTable[2003]);
	return 0;
}

int SupeCon(int Depth,int Border,int Num)
{
	int i;
	unsigned int WorkingNumber;

	for(i=Border;i<CountPrime;i++)
	{
		WorkingNumber=Num;
		WorkingNumber*=PrimeTable[i];

		if(WorkingNumber>MaxSupeCon)
		{
			if(i==Border)
				return 1;
			else 
				return 0;
		}

		if(Depth==12)
		{
			if(WorkingNumber>=n)
				SupeTable[CountSupe++]=WorkingNumber;
		}

		else{
			if(SupeCon(Depth+1,i,WorkingNumber)==1)
			{
				if(i==Border)
					return 1;
				else
					return 0;
			}
		}
	}
	return 0;
}


void CreateFactor()
{
	int i,j;

	for(i=2;i<MaxPrime;i+=2)
	{
		if(CountPrime==0)
			PrimeTable[CountPrime++]=i++;

		for(j=0;j<CountPrime;j++)
		{
			if(!(i%PrimeTable[j]))
				break;
		}

		if(j==CountPrime)
			PrimeTable[CountPrime++]=i;
	}
}

int comp(const void *x,const void *y)
{
	return *(int*)x-*(int*)y;
}

